document.addEventListener("DOMContentLoaded", () => {
    const registroInputs = document.querySelectorAll("#gestionClientes .carta input");
    const registrarBtn = document.querySelector("#gestionClientes .carta button");
    const tablaClientes = document.querySelector("#gestionClientes table tbody");

    function calcularNivel(puntos) {
        if (puntos >= 5000) return "🥇 VIP";
        if (puntos >= 1000) return "🥈 Preferente";
        return "🥉 Regular";
    }

    function crearFilaCliente(nombre, correo, telefono, puntos) {
        const nivel = calcularNivel(puntos);
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>🃏 ${nombre}</td>
            <td>📞 ${telefono}</td>
            <td>🎟️ ${puntos}</td>
            <td>${nivel}</td>
            <td>
                <button class="editar">✏️ Editar</button>
                <button class="eliminar">❌ Eliminar</button>
            </td>
        `;
        return fila;
    }

    registrarBtn.addEventListener("click", () => {
        const nombre = registroInputs[0].value.trim();
        const correo = registroInputs[1].value.trim();
        const telefono = registroInputs[2].value.trim();
        const puntos = parseInt(registroInputs[3].value.trim()) || 0;

        if (nombre && correo && telefono) {
            const fila = crearFilaCliente(nombre, correo, telefono, puntos);
            tablaClientes.appendChild(fila);
            limpiarCampos();
        } else {
            alert("Por favor, completa todos los campos.");
        }
    });

    function limpiarCampos() {
        registroInputs.forEach(input => input.value = "");
    }

    tablaClientes.addEventListener("click", e => {
        const btn = e.target;
        const fila = btn.closest("tr");

        if (btn.classList.contains("eliminar")) {
            fila.remove();
        }

        if (btn.classList.contains("editar")) {
            const celdas = fila.querySelectorAll("td");
            const nombre = celdas[0].textContent.replace("🃏 ", "").trim();
            const telefono = celdas[1].textContent.replace("📞 ", "").trim();
            const puntos = parseInt(celdas[2].textContent.replace("🎟️ ", "").trim());

            const nuevoTelefono = prompt(`Editar teléfono para ${nombre}:`, telefono);
            const nuevosPuntos = prompt(`Editar puntos para ${nombre}:`, puntos);

            if (nuevoTelefono !== null && nuevosPuntos !== null) {
                const puntosInt = parseInt(nuevosPuntos);
                if (!isNaN(puntosInt)) {
                    celdas[1].innerHTML = `📞 ${nuevoTelefono}`;
                    celdas[2].innerHTML = `🎟️ ${puntosInt}`;
                    celdas[3].textContent = calcularNivel(puntosInt);
                } else {
                    alert("Puntos inválidos.");
                }
            }
        }
    });
});
