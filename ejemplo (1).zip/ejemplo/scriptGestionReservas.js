// Array que almacenará las reservas
let reservas = [
    { cliente: "Manuel Torres", fecha: "2025-03-25", hora: "21:00", evento: "Sala de Juegos VIP" },
    { cliente: "Laura Gómez", fecha: "2025-03-27", hora: "19:30", evento: "Restaurante Privado" }
];

// Array de eventos próximos
let eventosProximos = [
    { evento: "Show en Vivo", fecha: "2025-03-28", hora: "22:00" },
    { evento: "Torneo de Póker", fecha: "2025-03-30", hora: "20:00" }
];

// Función para mostrar las reservas en la tabla
function mostrarReservas() {
    const tabla = document.querySelector("#tablaReservas tbody");
    tabla.innerHTML = "";  // Limpiar la tabla antes de agregar las nuevas reservas

    reservas.forEach((reserva, index) => {
        let row = tabla.insertRow();
        row.innerHTML = `
            <td>${reserva.cliente}</td>
            <td>${reserva.fecha}</td>
            <td>${reserva.hora}</td>
            <td>${reserva.evento}</td>
            <td><button class="eliminar" onclick="cancelarReserva(${index})">Cancelar</button></td>
        `;
    });
}

// Función para agendar una nueva reserva
function agendarReserva() {
    const cliente = document.querySelector("#nombreCliente").value;
    const fecha = document.querySelector("#fechaReserva").value;
    const hora = document.querySelector("#horaReserva").value;
    const evento = document.querySelector("#eventoReserva").value;

    if (cliente && fecha && hora) {
        // Agregar la nueva reserva al array
        reservas.push({
            cliente: cliente,
            fecha: fecha,
            hora: hora,
            evento: evento
        });

        // Limpiar los campos del formulario
        document.querySelector("#nombreCliente").value = "";
        document.querySelector("#fechaReserva").value = "";
        document.querySelector("#horaReserva").value = "";

        // Volver a mostrar la lista de reservas
        mostrarReservas();
        mostrarAlertasEventos();
    } else {
        alert("Por favor, complete todos los campos.");
    }
}

// Función para cancelar una reserva
function cancelarReserva(index) {
    reservas.splice(index, 1); // Eliminar la reserva del array
    mostrarReservas(); // Actualizar la tabla
    mostrarAlertasEventos(); // Recalcular las alertas de eventos próximos
}

// Función para mostrar las alertas de eventos próximos
function mostrarAlertasEventos() {
    const alertasContainer = document.querySelector("#alertasEventos");
    alertasContainer.innerHTML = ""; // Limpiar las alertas previas

    let fechaActual = new Date(); // Obtener la fecha actual
    let mensajeAlertas = [];

    // Verificar los eventos próximos
    eventosProximos.forEach(evento => {
        let fechaEvento = new Date(evento.fecha);
        let diferenciaDias = (fechaEvento - fechaActual) / (1000 * 3600 * 24); // Diferencia en días

        if (diferenciaDias <= 7 && diferenciaDias > 0) {
            mensajeAlertas.push(`⏳ <strong>${evento.evento}:</strong> ${evento.fecha} a las ${evento.hora}.`);
        }
    });

    // Mostrar las alertas
    if (mensajeAlertas.length > 0) {
        mensajeAlertas.forEach(mensaje => {
            let p = document.createElement("p");
            p.innerHTML = mensaje;
            alertasContainer.appendChild(p);
        });
    } else {
        let p = document.createElement("p");
        p.innerHTML = "No hay eventos próximos en los próximos 7 días.";
        alertasContainer.appendChild(p);
    }
}

// Mostrar las reservas y las alertas de eventos cuando se carga la página
window.onload = function() {
    mostrarReservas();
    mostrarAlertasEventos();
};
