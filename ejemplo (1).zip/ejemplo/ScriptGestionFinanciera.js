let transacciones = [];

function registrarTransaccion(tipo, monto, descripcion) {
    const transaccion = {
        id: Date.now(),
        tipo,
        monto: parseFloat(monto),
        descripcion,
        fecha: new Date().toLocaleString()
    };
    transacciones.push(transaccion);
    mostrarTransacciones();
    actualizarResumenFinanciero();
}

function mostrarTransacciones() {
    const tabla = document.getElementById("lista-transacciones");
    tabla.innerHTML = "";
    transacciones.forEach(t => {
        const fila = document.createElement("tr");

        fila.innerHTML = `
            <td>${t.tipo === 'ingreso' ? 'Ingreso' : 'Gasto'}</td>
            <td class="dinero" style="color: ${t.tipo === 'ingreso' ? 'green' : 'red'};">
                ${t.tipo === 'ingreso' ? '+' : '-'}$${t.monto.toFixed(2)}
            </td>
            <td>${t.descripcion}</td>
            <td>${t.fecha}</td>
        `;

        tabla.appendChild(fila);
    });
}

function actualizarResumenFinanciero() {
    let ingresos = 0;
    let gastos = 0;

    transacciones.forEach(t => {
        if (t.tipo === 'ingreso') ingresos += t.monto;
        else gastos += t.monto;
    });

    const gananciaNeta = ingresos - gastos;

    document.getElementById("total-ingresos").textContent = `+$${ingresos.toFixed(2)}`;
    document.getElementById("total-gastos").textContent = `-$${gastos.toFixed(2)}`;
    document.getElementById("ganancia-neta").textContent = `${gananciaNeta >= 0 ? '+' : '-'}$${Math.abs(gananciaNeta).toFixed(2)}`;
}

document.getElementById("form-finanzas").addEventListener("submit", function (e) {
    e.preventDefault();
    const tipo = document.getElementById("tipo-transaccion").value;
    const monto = document.getElementById("monto-transaccion").value;
    const descripcion = document.getElementById("descripcion-transaccion").value;

    if (!monto || monto <= 0 || descripcion.trim() === "") {
        alert("Por favor, complete todos los campos correctamente.");
        return;
    }

    registrarTransaccion(tipo, monto, descripcion);
    this.reset();
});

// Función extra: Exportar reporte (simple formato texto por ahora)
function descargarReporte() {
    let contenido = "REPORTE FINANCIERO\n\n";
    transacciones.forEach(t => {
        contenido += `${t.fecha} - ${t.tipo.toUpperCase()} - $${t.monto.toFixed(2)} - ${t.descripcion}\n`;
    });

    const blob = new Blob([contenido], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "reporte_financiero.txt";
    a.click();
    URL.revokeObjectURL(url);
}
