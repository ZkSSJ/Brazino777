// Array que almacenará a los empleados
let empleados = [
    { nombre: "Juan Pérez", puesto: "Crupier", salario: 1500, estado: "Activo", contratoVencimiento: "2025-04-25" },
    { nombre: "Carlos Ramírez", puesto: "Seguridad", salario: 1200, estado: "Activo", contratoVencimiento: "2025-05-05" }
];

// Vacantes disponibles
let vacantes = [
    { puesto: "Bartender", disponible: true }
];

// Función para mostrar los empleados en la tabla
function mostrarEmpleados() {
    const tabla = document.querySelector("#tablaEmpleados tbody");
    tabla.innerHTML = "";  // Limpiar la tabla antes de agregar los nuevos datos

    empleados.forEach((empleado, index) => {
        let row = tabla.insertRow();
        row.innerHTML = `
            <td>${empleado.nombre}</td>
            <td>${empleado.puesto}</td>
            <td>$${empleado.salario}</td>
            <td>🟢 ${empleado.estado}</td>
            <td><button class="eliminar" onclick="eliminarEmpleado(${index})">Eliminar</button></td>
        `;
    });
}

// Función para registrar un nuevo empleado
function registrarEmpleado() {
    const nombre = document.querySelector("#nombreEmpleado").value;
    const puesto = document.querySelector("#puestoEmpleado").value;
    const salario = document.querySelector("#salarioEmpleado").value;
    const tipo = document.querySelector("#tipoEmpleado").value;

    if (nombre && puesto && salario) {
        // Agregar el nuevo empleado al array
        empleados.push({
            nombre: nombre,
            puesto: puesto,
            salario: parseFloat(salario),
            estado: "Activo",
            contratoVencimiento: "2025-06-01" // Ejemplo, se puede cambiar por una fecha personalizada
        });

        // Limpiar los campos del formulario
        document.querySelector("#nombreEmpleado").value = "";
        document.querySelector("#puestoEmpleado").value = "";
        document.querySelector("#salarioEmpleado").value = "";

        // Volver a mostrar la lista de empleados
        mostrarEmpleados();
        mostrarNotificaciones();
    } else {
        alert("Por favor, complete todos los campos.");
    }
}

// Función para eliminar un empleado
function eliminarEmpleado(index) {
    empleados.splice(index, 1); // Eliminar el empleado del array
    mostrarEmpleados(); // Actualizar la tabla
    mostrarNotificaciones(); // Recalcular las notificaciones
}

// Función para mostrar las notificaciones
function mostrarNotificaciones() {
    const notificacionesContainer = document.querySelector("#notificacionesHR");
    notificacionesContainer.innerHTML = ""; // Limpiar las notificaciones previas

    let fechaActual = new Date(); // Obtener la fecha actual
    let mensajeNotificaciones = [];

    // Verificar los contratos que están por vencer
    empleados.forEach(empleado => {
        let fechaVencimiento = new Date(empleado.contratoVencimiento);
        let diferenciaDias = (fechaVencimiento - fechaActual) / (1000 * 3600 * 24); // Diferencia en días

        if (diferenciaDias <= 7 && diferenciaDias > 0) {
            mensajeNotificaciones.push(`🕒 <strong>${empleado.nombre}</strong>: Contrato vence en ${Math.floor(diferenciaDias)} días.`);
        }
    });

    // Verificar si hay vacantes disponibles
    vacantes.forEach(vacante => {
        if (vacante.disponible) {
            mensajeNotificaciones.push(`📋 <strong>Nueva Vacante:</strong> Se necesita un nuevo ${vacante.puesto}.`);
        }
    });

    // Mostrar las notificaciones
    if (mensajeNotificaciones.length > 0) {
        mensajeNotificaciones.forEach(mensaje => {
            let p = document.createElement("p");
            p.innerHTML = mensaje;
            notificacionesContainer.appendChild(p);
        });
    } else {
        let p = document.createElement("p");
        p.innerHTML = "No hay notificaciones recientes.";
        notificacionesContainer.appendChild(p);
    }
}

// Mostrar los empleados y las notificaciones cuando se carga la página
window.onload = function() {
    mostrarEmpleados();
    mostrarNotificaciones();
};
