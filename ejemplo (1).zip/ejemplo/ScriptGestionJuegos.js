let juegos = [];

function agregarJuego(nombre, tipo, estado) {
    if (!nombre.trim() || !tipo.trim() || !estado.trim()) {
        alert("Por favor completa todos los campos.");
        return;
    }

    const juego = {
        id: Date.now(),
        nombre,
        tipo,
        estado
    };
    juegos.push(juego);
    mostrarJuegos();
}

function editarEstadoJuego(id) {
    const juego = juegos.find(j => j.id === id);
    if (juego) {
        juego.estado = juego.estado === "🟢 Activo" ? "🔴 Inactivo" : "🟢 Activo";
        mostrarJuegos();
    }
}

function eliminarJuego(id) {
    if (confirm("¿Estás seguro de eliminar este juego?")) {
        juegos = juegos.filter(j => j.id !== id);
        mostrarJuegos();
    }
}

function mostrarJuegos() {
    const lista = document.getElementById("lista-juegos");
    lista.innerHTML = "";

    juegos.forEach(juego => {
        lista.innerHTML += `
            <tr>
                <td>${juego.nombre}</td>
                <td>${juego.tipo}</td>
                <td>${juego.estado}</td>
                <td>
                    <button onclick="editarEstadoJuego(${juego.id})">
                        Cambiar a ${juego.estado === "🟢 Activo" ? "🔴 Inactivo" : "🟢 Activo"}
                    </button>
                    <button onclick="eliminarJuego(${juego.id})">Eliminar</button>
                </td>
            </tr>
        `;
    });
}

document.getElementById("form-juego").addEventListener("submit", function(e) {
    e.preventDefault();
    const nombre = document.getElementById("nombre-juego").value;
    const tipo = document.getElementById("tipo-juego").value;
    const estado = document.getElementById("estado-juego").value;
    agregarJuego(nombre, tipo, estado);
    this.reset();
});
