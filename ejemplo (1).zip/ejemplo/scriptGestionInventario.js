// Array para almacenar los productos en el inventario
let inventario = [
    { nombre: "Barajas de Póker", categoria: "Cartas y Fichas", cantidad: 50 },
    { nombre: "Botellas de Whisky", categoria: "Bebidas", cantidad: 20 }
];

// Función para mostrar los productos en el inventario
function mostrarInventario() {
    const tabla = document.querySelector("#tablaInventario tbody");
    tabla.innerHTML = ""; // Limpiar la tabla antes de agregar nuevos productos

    inventario.forEach((producto, index) => {
        let row = tabla.insertRow();
        row.innerHTML = `
            <td>${producto.nombre}</td>
            <td>${producto.categoria}</td>
            <td>${producto.cantidad}</td>
            <td>${producto.cantidad <= 5 ? "🟡 Pocas Unidades" : "🟢 Disponible"}</td>
            <td><button class="eliminar" onclick="eliminarProducto(${index})">Eliminar</button></td>
        `;
    });

    mostrarAlertasStock(); // Actualizar las alertas de stock
}

// Función para agregar un nuevo producto al inventario
function agregarProducto() {
    const nombre = document.querySelector("#nombreProducto").value;
    const cantidad = parseInt(document.querySelector("#cantidadProducto").value);
    const categoria = document.querySelector("#categoriaProducto").value;

    if (nombre && cantidad > 0) {
        // Agregar el producto al inventario
        inventario.push({
            nombre: nombre,
            categoria: categoria,
            cantidad: cantidad
        });

        // Limpiar los campos del formulario
        document.querySelector("#nombreProducto").value = "";
        document.querySelector("#cantidadProducto").value = "";

        // Mostrar el inventario actualizado
        mostrarInventario();
    } else {
        alert("Por favor, complete todos los campos correctamente.");
    }
}

// Función para eliminar un producto del inventario
function eliminarProducto(index) {
    inventario.splice(index, 1); // Eliminar el producto del array
    mostrarInventario(); // Actualizar la tabla de inventario
}

// Función para mostrar las alertas de productos con pocas unidades
function mostrarAlertasStock() {
    const alertasContainer = document.querySelector("#alertasStock");
    alertasContainer.innerHTML = ""; // Limpiar las alertas previas

    let productosEnRiesgo = inventario.filter(producto => producto.cantidad <= 5);

    if (productosEnRiesgo.length > 0) {
        productosEnRiesgo.forEach(producto => {
            let p = document.createElement("p");
            p.innerHTML = `${producto.categoria} <strong>${producto.nombre}:</strong> Quedan solo ${producto.cantidad} unidades.`;
            alertasContainer.appendChild(p);
        });
    } else {
        let p = document.createElement("p");
        p.innerHTML = "No hay productos en riesgo de agotarse.";
        alertasContainer.appendChild(p);
    }
}

// Mostrar el inventario y las alertas de stock al cargar la página
window.onload = function() {
    mostrarInventario();
};
