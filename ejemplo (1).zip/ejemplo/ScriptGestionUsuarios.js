let usuarios = [];

function agregarUsuario() {
    const nombre = document.getElementById('nombreUsuario').value;
    const correo = document.getElementById('correoUsuario').value;
    const rol = document.getElementById('rolUsuario').value;

    if (nombre && correo && rol) {
        const nuevoUsuario = { nombre, correo, rol, estado: "🟢 Activo" };
        usuarios.push(nuevoUsuario);
        actualizarTablaUsuarios();
        limpiarFormularioUsuarios();
    } else {
        alert("Por favor completa todos los campos.");
    }
}

function eliminarUsuario(index) {
    if (confirm("¿Deseas eliminar este usuario?")) {
        usuarios.splice(index, 1);
        actualizarTablaUsuarios();
    }
}

function actualizarTablaUsuarios() {
    const tbody = document.getElementById('tablaUsuarios').querySelector('tbody');
    tbody.innerHTML = "";

    usuarios.forEach((usuario, index) => {
        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${usuario.nombre}</td>
            <td>${usuario.rol}</td>
            <td>${usuario.estado}</td>
            <td><button class="eliminar" onclick="eliminarUsuario(${index})">Eliminar</button></td>
        `;
        tbody.appendChild(fila);
    });
}

function limpiarFormularioUsuarios() {
    document.getElementById('nombreUsuario').value = '';
    document.getElementById('correoUsuario').value = '';
    document.getElementById('rolUsuario').value = ''; }